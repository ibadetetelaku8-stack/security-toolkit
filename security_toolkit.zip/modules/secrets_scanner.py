# secrets scanner module
